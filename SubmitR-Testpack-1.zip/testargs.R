options(echo=FALSE) 
args <- commandArgs(TRUE) # Only "--args..."
cat("Test=[","]\n",sep="!")
cat("Args=[",args,"]\n")


